<?php
$conn = mysqli_connect("localhost", "root", "", "php-kuiz") or die("could not connect" . mysqli_error($conn) ) ;
?>
